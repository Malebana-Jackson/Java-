
package human_prog.emp;


public class Clerk extends Employee {
    
    public Clerk(String employee_id, String name, String department, double salary, String designation) {
        super(employee_id, name, department, salary, designation);
    }

      public double addBonus(){
      //default bonus 20000.00
     
      return this.salary+=1000.00;
     
    
    }
    
    public void display(){
    
        System.out.println(new Manager(employee_id,name,department,salary,designation)+"");
    
    }

    @Override
    public String toString() {
        return super.toString(); 
    }


    
    
    
    
    
}
