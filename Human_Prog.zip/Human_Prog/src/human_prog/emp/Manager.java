
package human_prog.emp;


public class Manager extends Employee {

    public Manager(String employee_id, String name, String department, double salary, String designation) {
        super(employee_id, name, department, salary, designation);
    }
    


    
    public double addBonus(double bonus){
        //default bonus 20000.00
       return this.salary+=bonus;
     
    
    }
    
    public void display(){
       
        System.out.println(new Manager(employee_id,name,department,salary,designation)+"");
    
    }

    
    @Override
    public String toString() {
        return super.toString();  }

    @Override
    public boolean equals(String designation) {
        return this.
                .equals(designation);     }
    
    
    
    
}
