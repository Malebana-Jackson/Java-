
package human_prog.pers;


public class Teacher extends Person {
    
    private String subject_name;
    private double salary;
    
    public Teacher(String name, String surname, String subject_name,double salary) {
        super(name, surname);
        this.subject_name = subject_name;
        this.salary = salary;
    }

    public String getSubject_name() {
        return subject_name;
    }

    public void setSubject_name(String subject_name) {
        this.subject_name = subject_name;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public void displayDetails() {
        super.displayDetails(); 
        System.out.println(new Teacher(name,surname,subject_name,salary)+"");
    }

    @Override
    public String toString() {
        return "Teacher{" + "subject_name=" + subject_name + ", salary =" + salary + '}' + super.toString();
    }
    
    
    
    
    

}