
package human_prog.pers;


public class Student extends Person {
    private String student_id, teacher_name,course;
    
    public Student(String name, String surname,String student_id,String teacher_name,String course) {
        super(name, surname);
        this.student_id =student_id;
        this.teacher_name = teacher_name;
        this.course =course;
    }

    public String getStudent_id() {
        return student_id;
    }

    public void setStudent_id(String student_id) {
        this.student_id = student_id;
    }

    public String getTeacher_name() {
        return teacher_name;
    }

    public void setTeacher_name(String teacher_name) {
        this.teacher_name = teacher_name;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    @Override
    public String toString() {
        return "Student{" + "student_id=" + student_id + ", teacher_name=" + teacher_name + ", course=" + course + '}';
    }

    
        @Override
    public void displayDetails() {
        super.displayDetails();
       System.out.println(new Student(name,surname,student_id,teacher_name,course)+"");
   }

    
}
