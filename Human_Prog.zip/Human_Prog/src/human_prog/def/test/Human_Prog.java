
package human_prog.def.test;

import human_prog.pers.Teacher;
import human_prog.pers.Student;
import human_prog.emp.Clerk;
import human_prog.emp.Manager;


public class Human_Prog {

    public static void main(String[] args) {
       
      
        Student student1 = new Student(" Clark"," Kent"," 8uP3rm"," Louis Lane", " Journalism");
        Student student2 = new Student(" Bruce"," Wayne"," b4ts13"," Alfred Pennyworth", " Self Defence");
        Teacher teacher1 = new Teacher(" James"," Bond"," English", 25000.00);
        Teacher teacher2 = new Teacher(" Juke"," Box"," Music", 35000.00);
        
        Manager manager1 = new Manager(" tf76bbc"," Rakim"," Engineering", 25000.00," Education");
        Manager manager2 = new Manager(" 5f7vv2y"," Fredo"," Production", 35000.00," Education");
        Clerk clerk1 = new Clerk(" 657fgbc"," Andre"," Supply", 15000.00," HelpDesk");
        Clerk clerk2 = new Clerk(" 67fffp"," Aubrey"," IT", 10000.00," HelpDesk");
        
       student1.displayDetails();
       student2.displayDetails();
       teacher1.displayDetails();
       teacher2.displayDetails();
       
       System.out.println(" ");
       manager1.display();
       manager2.display();
       clerk1.display();
       clerk2.display();
       manager1.addBonus(2000.00);
       manager1.equals("Musician");
        
        
       new Human_Prog().calcSalary();
    
}

    private void calcSalary() {
        
     
        
        
        
//        Deduction array[] = {
//        "Mac Miller", "Isaiah Rashad", "Mick Jenkins"
//        
//        
//        };
        
          }

 
    }
