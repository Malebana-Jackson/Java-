
package human_prog.def.test;


class Deduction {
    
      private int missed_days ;
       private double rates, salary;

    public Deduction(int missed_days, double rates, double salary) {
        this.missed_days = missed_days;
        this.rates = rates;
        this.salary = salary;
    }




    public int getMissed_days() {
        return missed_days;
    }

    public void setMissed_days(int missed_days) {
        this.missed_days = missed_days;
    }

    public double getRates() {
        return rates;
    }

    public void setRates(double rates) {
        this.rates = rates;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Deduction{" + "missed_days=" + missed_days + ", rates=" + rates + ", salary=" + salary + '}';
    }
       
       
       
}
