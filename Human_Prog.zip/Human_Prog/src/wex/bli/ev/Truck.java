
package wex.bli.ev;

import human_prog.pers.Person;

public class Truck extends Vechile{
    
    private double loadcapcity;
    private int towcapacity;
    public Truck(String manufacturer, int cylinders, Person owner,double loadcapcity,int towcapacity) {
        super(manufacturer, cylinders, owner);
        this.loadcapcity=loadcapcity;
        this.towcapacity=towcapacity;
    }

    public double getLoadcapcity() {
        return loadcapcity;
    }

    public void setLoadcapcity(double loadcapcity) {
        this.loadcapcity = loadcapcity;
    }

    public int getTowcapacity() {
        return towcapacity;
    }

    public void setTowcapacity(int towcapacity) {
        this.towcapacity = towcapacity;
    }
    
    
    
}
