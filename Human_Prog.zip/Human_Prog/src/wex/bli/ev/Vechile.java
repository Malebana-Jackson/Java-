
package wex.bli.ev;

import human_prog.pers.Person;


public class Vechile {
    
   private String manufacturer;
   private int cylinders;
   private Person owner;

    public Vechile(String manufacturer, int cylinders, Person owner) {
        this.manufacturer = manufacturer;
        this.cylinders = cylinders;
        this.owner = owner;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public int getCylinders() {
        return cylinders;
    }

    public void setCylinders(int cylinders) {
        this.cylinders = cylinders;
    }

    public Person getOwner() {
        return owner;
    }

    public void setOwner(Person owner) {
        this.owner = owner;
    }
   
   
   
   
}
